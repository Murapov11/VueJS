<template>
  <footer>
    <p>&copy; 2024 Mini Blog. All rights reserved.</p>
  </footer>
</template>

<script>
export default {
  name: 'AppFooter',
}
</script>

<style scoped>
footer {
  text-align: center;
  padding: 10px;
  background-color: #f1f1f1;
}
</style>
