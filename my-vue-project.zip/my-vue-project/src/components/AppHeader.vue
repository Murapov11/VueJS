<template>
  <header>
    <h1>Football Teames</h1>
  </header>
</template>

<script>
export default {
  name: 'AppHeader',
}
</script>

<style scoped>
header {
  background-color: #2c3e50;
  color: white;
  padding: 20px;
}
</style>
